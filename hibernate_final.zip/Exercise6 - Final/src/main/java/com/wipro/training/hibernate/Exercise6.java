package com.wipro.training.hibernate;

/**
 * Created by e068636 on 6/28/2017.
 */
public class Exercise6 {

    public static void main(String args[]) {



    }

}
