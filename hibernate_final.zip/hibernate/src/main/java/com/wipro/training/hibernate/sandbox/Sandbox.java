package com.wipro.training.hibernate.sandbox;

public class Sandbox {
	public static void main(final String[] args) {
	}
}
